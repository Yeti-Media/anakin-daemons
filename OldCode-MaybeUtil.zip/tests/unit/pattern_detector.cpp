/*

    #define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE PatternDetector
#include <boost/test/unit_test.hpp>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv;

BOOST_AUTO_TEST_CASE(constructor)
{


//    BOOST_CHECK(!detector.getObjects()[0].image.data == false);
};

*/
